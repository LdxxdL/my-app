import React from 'react'
import { connect } from 'react-redux'
import { Redirect } from 'react-router-dom'

import { login, getUserData } from './Auth.redux'

//两个reducers 每个reducers都有一个state
@connect(
  state=>state.auth,
  {login, getUserData}
)
class Auth extends React.Component{
  constructor(props, context) {
    super(props, context);
    this.state={
      data:{}
    }
  }
  componentDidMount() {
    this.props.getUserData()
    console.log(this.props.getUserData)
  }
  render() {
    return (
      <div>
        <h2>My name is {this.props.user}</h2>
        <h2>My age is {this.props.age}</h2>
        { this.props.isAuth?<Redirect to='/dashBoard'></Redirect>:null }
        <h2>You need to login</h2>
        <button onClick={this.props.login}>登录</button>
      </div>
    )
  }
}


export default Auth