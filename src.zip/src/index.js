
import React from 'react';
import ReactDom from 'react-dom';
import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';

import './config'
import 'antd-mobile/dist/antd-mobile.css'

import reducers from './reducers'
import Auth from './Auth';
import DashBoard from './DashBoard';


const reduxDevtools = window.devToolsExtension?window.devToolsExtension():()=>{};
export const store = createStore(reducers, compose(
  applyMiddleware(thunk),
  reduxDevtools
));
console.log(store.getState());

ReactDom.render(
  (<Provider store={store}>
    <BrowserRouter>
        <Switch>
          {/* 只渲染命中的第一个Router */}
          <Route path='/login' exact component={Auth}></Route>
          <Route path='/dashBoard' component={DashBoard}></Route>
          <Redirect to='/dashBoard'></Redirect>
        </Switch>
    </BrowserRouter>
  </Provider>),
  document.getElementById('root')
);


