const ADD_GUN = '添加机关枪';
const REMOVE_GUN = '移除机关枪'

//通过reducer，根据老的state和action，生成新的state
export function counter(state=10, action) {
	switch (action.type) {
		case ADD_GUN:
			return state + 1;
		case REMOVE_GUN:
			return state - 1;
		default:
			return state;
	}
}

//action creator
export function addGun() {
	return {
		type: ADD_GUN
	}
}
//action remove
export function removeGun() {
	return {
		type: REMOVE_GUN
	}
}

export function addGunAsync() {
  return (dispatch)=>{
    setTimeout(() => {
      dispatch(addGun());
    }, 2000);
  }
}