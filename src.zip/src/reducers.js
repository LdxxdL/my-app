
import { combineReducers } from 'redux'

import { counter } from './index.redux';
import { auth } from './Auth.redux'

//用于合并所有的reducers 并返回
export default combineReducers({counter,auth})


