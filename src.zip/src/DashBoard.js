import React from 'react'
import { Route, Link, Redirect, Switch } from 'react-router-dom'
import { connect } from 'react-redux'

import App from './App'
import { logout } from './Auth.redux'

function Army2() {
  return <h2>二营</h2>
}
function Company() {
  return <h2>骑兵连</h2>
}

@connect(
  state=>{return {isAuth: state.auth.isAuth}},
  {logout}
)
class DashBoard extends React.Component{
  render() {
    const match = this.props.match;
    const redirectToLogin = <Redirect to='./login'></Redirect>
    const app = (
      <div>
        <h1>独立团</h1>
        <button onClick={this.props.logout}>注销</button>
        <ul>
          <li>
            <Link to={`${match.url}`}>一营</Link>
          </li>
          <li>
            <Link to={`${match.url}/Army2`}>二营</Link>
          </li>
          <li>
            <Link to={`${match.url}/Company`}>骑兵连</Link>
          </li>
        </ul>
        <Switch>
          <Route path={`${match.url}`} exact component={App}></Route>
          <Route path={`${match.url}/Army2`} component={Army2}></Route>
          <Route path={`${match.url}/Company`} component={Company}></Route>
          <Redirect to={`${match.url}`}></Redirect>
        </Switch>
      </div>
    )
    return this.props.isAuth?app:redirectToLogin
  }
}

export default DashBoard