
import React from 'react';
import { connect } from 'react-redux';
import { addGun, removeGun, addGunAsync } from './index.redux';
// import { store } from './index';

@connect(
  //第一个参数：将state中的属性放入props中
  (state)=>{return {num: state.counter}},
  //第二个参数：redux中的方法放入props中，自动使用dispatch
  { addGun, removeGun, addGunAsync }
)
class App extends React.Component{
	render() {
		return (
			<div>
				<h1>现在有{this.props.num}把机枪</h1>
				<button onClick={this.props.addGun}>添加武器</button>
        <button onClick={this.props.removeGun}>移除武器</button>
        <button onClick={this.props.addGunAsync}>延时添加武器</button>
			</div>
		)
	}
}

export default App;
